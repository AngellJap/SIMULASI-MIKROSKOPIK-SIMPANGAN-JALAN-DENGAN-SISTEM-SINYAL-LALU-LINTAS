export function drawSelatan(ctx, config) {
  const totalMasuk = config.selatan.in;
  const totalKeluar = config.selatan.out;
  const skala = config.skala_px * 3; // 3 meter per lajur
  const lebarJalan = (totalMasuk + totalKeluar) * skala;

  const centerX = ctx.canvas.width / 2;
  const centerY = ctx.canvas.height / 2;

  const startY = centerY + 100;
  const endY = ctx.canvas.height;
  const startX = centerX - lebarJalan / 2;

  // Gambar background putih di bawah
  ctx.fillStyle = 'white';
  ctx.fillRect(0, startY, ctx.canvas.width, endY - startY);

  // Gambar jalan selatan (dua arah)
  ctx.fillStyle = 'DimGray';
  ctx.fillRect(startX, startY, lebarJalan, endY - startY);

  // Garis tegas pemisah masuk & keluar
  const garisPembatasX = startX + totalMasuk * skala;
  ctx.strokeStyle = 'white';
  ctx.setLineDash([]); // garis lurus
  ctx.lineWidth = 4;

  ctx.beginPath();
  ctx.moveTo(garisPembatasX, startY);
  ctx.lineTo(garisPembatasX, endY);
  ctx.stroke();

  // Marka lajur masuk (kanan)
  ctx.strokeStyle = 'white';
  ctx.setLineDash([10, 10]);
  ctx.lineWidth = 2;

  for (let i = 1; i < totalMasuk; i++) {
    const x = startX + i * skala;
    ctx.beginPath();
    ctx.moveTo(x, startY);
    ctx.lineTo(x, endY);
    ctx.stroke();
  }

  // Marka lajur keluar (kiri)
  for (let i = 1; i < totalKeluar; i++) {
    const x = garisPembatasX + i * skala;
    ctx.beginPath();
    ctx.moveTo(x, startY);
    ctx.lineTo(x, endY);
    ctx.stroke();
  }

  ctx.setLineDash([]);
}
