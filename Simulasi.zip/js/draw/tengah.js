export function drawTengah(ctx, config) {
  const centerSize = 200; // ukuran area pusat simpangan
  const canvasCenter = {
    x: ctx.canvas.width / 2,
    y: ctx.canvas.height / 2
  };

  ctx.fillStyle = 'DimGray';
  ctx.fillRect(
    canvasCenter.x - centerSize / 2,
    canvasCenter.y - centerSize / 2,
    centerSize,
    centerSize
  );

  // Marka tengah (garis putus-putus putih)
  ctx.strokeStyle = 'white';
  ctx.setLineDash([10, 10]);
  ctx.lineWidth = 2;

  ctx.beginPath();
  ctx.moveTo(canvasCenter.x - centerSize / 2, canvasCenter.y);
  ctx.lineTo(canvasCenter.x + centerSize / 2, canvasCenter.y);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(canvasCenter.x, canvasCenter.y - centerSize / 2);
  ctx.lineTo(canvasCenter.x, canvasCenter.y + centerSize / 2);
  ctx.stroke();

  ctx.setLineDash([]);
}
