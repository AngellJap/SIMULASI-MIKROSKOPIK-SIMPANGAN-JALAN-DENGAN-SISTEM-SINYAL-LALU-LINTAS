export function drawUtara(ctx, config) {
  const totalMasuk = config.utara.in;
  const totalKeluar = config.utara.out;
  const skala = config.skala_px * 3;
  const lebarJalan = (totalMasuk + totalKeluar) * skala;

  const centerX = ctx.canvas.width / 2;
  const centerY = ctx.canvas.height / 2;

  const startY = 0;
  const endY = centerY - 100;
  const startX = centerX - lebarJalan / 2;

  // Gambar background putih (area bukan jalan)
  ctx.fillStyle = 'white';
  ctx.fillRect(0, 0, ctx.canvas.width, endY);

  // Gambar jalan
  ctx.fillStyle = 'DimGray';
  ctx.fillRect(startX, startY, lebarJalan, endY - startY);

  // Garis tegas pemisah masuk & keluar
  const garisPembatasX = startX + totalMasuk * skala;
  ctx.strokeStyle = 'white';
  ctx.setLineDash([]); // garis lurus
  ctx.lineWidth = 4;

  ctx.beginPath();
  ctx.moveTo(garisPembatasX, startY);
  ctx.lineTo(garisPembatasX, endY);
  ctx.stroke();

  // Marka putus-putus antar lajur masuk
  ctx.strokeStyle = 'white';
  ctx.setLineDash([10, 10]);
  ctx.lineWidth = 2;

  for (let i = 1; i < totalMasuk; i++) {
    const x = startX + i * skala;
    ctx.beginPath();
    ctx.moveTo(x, startY);
    ctx.lineTo(x, endY);
    ctx.stroke();
  }

  // Marka putus-putus antar lajur keluar
  for (let i = 1; i < totalKeluar; i++) {
    const x = garisPembatasX + i * skala;
    ctx.beginPath();
    ctx.moveTo(x, startY);
    ctx.lineTo(x, endY);
    ctx.stroke();
  }

  ctx.setLineDash([]);
}
